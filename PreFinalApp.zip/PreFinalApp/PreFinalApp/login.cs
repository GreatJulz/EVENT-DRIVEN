﻿using PreFinalApp.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PreFinalApp
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string conString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\COMLAB507\\Downloads\\PreFinalApp\\PreFinalApp\\Database1.mdf;Integrated Security=True";

            using (var db = new MyDbContextV2(conString))
            {
                var username = textBoxUsername.Text;
                var password = textBoxPassword.Text;

                var existingUser = (from row in db.UserLogins
                                    where row.Username == username
            && row.Password == password
                                    select row).FirstOrDefault();

                if (existingUser != null)
                {
                    frmMaster master = new frmMaster();
                    master.ShowDialog();
                }

                else
                {
                    MessageBox.Show("Invalid Username or Password!! ", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
