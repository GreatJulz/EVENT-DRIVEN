﻿using PreFinalApp.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PreFinalApp
{
    public partial class frmFileManagement : Form
    {
        public int SelectedID = 0;

        public frmFileManagement()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            Console.WriteLine($"Selected ID: {SelectedID}");
            string conString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\COMLAB507\\Downloads\\PreFinalApp\\PreFinalApp\\Database1.mdf;Integrated Security=True";

            using (var db = new MyDbContextV2(conString)) 
            {
                var selRow = (from row in db.Students where row.Id == SelectedID select row).FirstOrDefault();

                if (selRow != null) 
                { 
                    listBox1.Items.Add(selRow.Id);
                    listBox1.Items.Add(selRow.FirstName);
                    listBox1.Items.Add(selRow.LastName);
                    listBox1.Items.Add(selRow.EmailAddress);
                    listBox1.Items.Add(selRow.StudentId);
                }
            }
        }
    }
}
