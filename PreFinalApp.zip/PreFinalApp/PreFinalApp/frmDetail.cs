﻿using PreFinalApp.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PreFinalApp
{
    public partial class frmDetail : Form
    {
        string conString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Personals\\STI\\LabActivities\\EventDriven\\PreFinalApp\\Database1.mdf;Integrated Security=True";

        public int SelectedID = 0;
        public frmDetail()
        {
            InitializeComponent();
        }


        private void btnSave_Click(object sender, EventArgs e)
        {            
            using (var db = new MyDbContextV2(conString))             
            {
                //If SelectedID is -1 this Data would be NULL, then we create new record
                
                if (SelectedID == -1)
                {
                    Student stud = new Student()
                    {
                        LastName = txtLastName.Text,
                        FirstName = txtFirstName.Text,
                        EmailAddress = txtEmail.Text,
                        StudentId = txtStudID.Text
                    };

                    db.Students.Add(stud);
                    db.SaveChanges();

                }
                else // existing would edited and updated
                {
                    var studentData = (from row in db.Students where row.Id == SelectedID select row).FirstOrDefault();
                    studentData.LastName = txtLastName.Text;
                    studentData.FirstName = txtFirstName.Text;
                    studentData.EmailAddress = txtEmail.Text;
                    studentData.StudentId = txtStudID.Text;
                    db.SaveChanges();
                }               

                
                MessageBox.Show("Record has been saved");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if(SelectedID == -1) 
            {
                this.Text = "New Record";
            }
            else 
            {
                this.Text = $"Editing Record No: {SelectedID}";
                LoadData(SelectedID);
            }
        }

        private void LoadData(int sID) 
        {
            
            using (var db = new MyDbContextV2(conString))
            {
                var studentData = (from row in db.Students where row.Id == sID select row).FirstOrDefault();//LINQ
                if (studentData != null)
                {
                    txtLastName.Text = studentData.LastName;
                    txtFirstName.Text = studentData.FirstName;
                    txtEmail.Text = studentData.EmailAddress;
                    txtStudID.Text = studentData.StudentId;
                }                
            }
        }
    }
}
